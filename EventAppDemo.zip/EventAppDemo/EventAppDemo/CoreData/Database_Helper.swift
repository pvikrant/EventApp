//
//  Database-Helper.swift
//  EventAppDemo
//
//  Created by AppEdify TechnoWorld on 26/02/2021.
//


import CoreData
import UIKit

class Database_Helper{
    
    // MARK: - Declearation of share Instance for Database_Helper class.
    static let sharedInstance = Database_Helper()
    
    // MARK: - NSManagedObjectContext
    func getContext() -> NSManagedObjectContext
        {
            let delegate = UIApplication.shared.delegate as? AppDelegate

            return (delegate?.persistentContainer.viewContext)!
        }
    // MARK: - Delete NSManagedObject by using onDelete function.
    public func onDelete(entityName:String){
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        if let result = try? Database_Helper.sharedInstance.getContext().fetch(fetchRequest) {
            for object in result {
                Database_Helper.sharedInstance.getContext().delete(object as! NSManagedObject)
            }
        }
    }
    // MARK: - Save data into NSManagedObject by using onSave function.
    public func onSave<T:NSManagedObject>(_type: T.Type)-> T?
        {
            guard let entityName = T.entity().name else {return nil}
            guard let entity = NSEntityDescription.entity(forEntityName: entityName, in: getContext()) else {return nil}
            let object = T(entity: entity, insertInto: getContext())
            return object
        }
    // MARK: - Fetch data from CoreData by using onFetch function.
    public func onFetch<E:NSManagedObject>(entityName:String)-> [E] {
        let request = NSFetchRequest<NSManagedObject>(entityName: entityName)
        do{
            let result = try getContext().fetch(request)
            return result as! [E]
        }catch{
            print(error.localizedDescription)
            return []
        }
    }
    // MARK: - Fetch data with Predicate fillter from CoreData by using onFetchWithPredicate function.
    public func onFetchWithPredicate<E:NSManagedObject>(entityName:String,fillterFormet:String,byId:Int)-> [E] {
        let request = NSFetchRequest<NSManagedObject>(entityName: entityName)
        request.predicate = NSPredicate(format: fillterFormet, byId)
        do{
            let result = try getContext().fetch(request)
            return result as! [E]
        }catch{
            print(error.localizedDescription)
            return []
        }
    }
}
