//
//  Event_List_Model.swift
//  EventAppDemo
//
//  Created by AppEdify TechnoWorld on 23/02/2021.
//


import Foundation
import UIKit
import CoreData

// MARK: - Event List Model
struct Event_List_Model: Codable
{
    var event_id: Int
    var event_title,event_location,event_time: String
    // MARK: - Save event list data into Core Data using model.
    func onSaveEventList() {
        guard let event = Database_Helper.sharedInstance.onSave(_type: EventList.self) else { return }
        event.event_id = Int16(event_id)
        event.event_title = event_title
        event.event_location = event_location
        event.event_time = event_time
        do{
            try Database_Helper.sharedInstance.getContext().save()
        }catch{
            print("Data is not saved.")
        }
    }
}
// MARK: - Event Details Model
struct address: Decodable {
    var street,suite,city,zipcode: String
    let geo: geo!
}
struct geo: Decodable {
    var lat,lng: String
}
struct company: Decodable {
    var name,catchPhrase,bs: String
}
struct wifi: Decodable {
    var wifi_name,wifi_password: String
}
struct Event_Details_Model: Decodable {
    var id: Int
    var event_image,event_title, event_location, event_time, name , username, email, phone, website,description: String?
    var company: company!
    var address: address!
    var wifi: wifi!
    
    // MARK: - Save event details data into Core Data using model.
    func onSaveEventDetails() {
        guard let eventObject = Database_Helper.sharedInstance.onSave(_type: EventDetails.self) else { return }
        
        eventObject.d_event_id = Int16(id)
        eventObject.d_event_image = event_image
        eventObject.d_event_title = event_title
        eventObject.d_event_location = event_location
        eventObject.d_event_time = event_time
        eventObject.d_event_name = name
        eventObject.d_event_username = username
        eventObject.d_event_email = email
        eventObject.d_event_description = description
        eventObject.d_event_wifi_name = wifi.wifi_name
        eventObject.d_event_wifi_password = wifi.wifi_password
        eventObject.d_event_phone = phone
        eventObject.d_event_website = website
        eventObject.d_event_street = address.street
        eventObject.d_event_suite = address.suite
        eventObject.d_event_city = address.city
        eventObject.d_event_zipcode = address.zipcode
        eventObject.d_event_lat = address.geo.lat
        eventObject.d_event_lng = address.geo.lng
        eventObject.d_event_comp_name = company.name
        eventObject.d_event_catchphrase = company.catchPhrase
        eventObject.d_event_bs = company.bs
        
        do{
            try Database_Helper.sharedInstance.getContext().save()
        }catch{
            print("Data is not saved.")
        }
    }
}

// MARK: - Decoder data from JSON file using JSONDecoder.
func getObjectWith(jsonFileName: String)
 {
    let decoder = JSONDecoder()
    do {
        let baseUrl = URL(string:"https://raw.githubusercontent.com/pvikrant/sampleJson.github.io/main/\(jsonFileName).json")
        let jsonString = try String(contentsOf: baseUrl!)
        let jsonData = Data(jsonString.utf8)
        
        // MARK: - Fetch data from EventList JSON file.
        if jsonFileName == "events_list"
        {
            let arrEvents = try decoder.decode([Event_List_Model].self, from: jsonData)
            Database_Helper.sharedInstance.onDelete(entityName: "EventList")
            arrEvents.forEach{$0.onSaveEventList()}
        }
        // MARK: - Fetch data from EventDetails JSON file.
        else if jsonFileName == "events_details"
        {
            do {
                let arrEvents = try decoder.decode([Event_Details_Model].self, from: jsonData)
                Database_Helper.sharedInstance.onDelete(entityName: "EventDetails")
                arrEvents.forEach{$0.onSaveEventDetails()}
            } catch {
                print(error)
            }
        }
        return
    } catch
    {
        debugPrint(error)
    }
}

