//
//  ViewController.swift
//  EventAppDemo
//
//  Created by AppEdify TechnoWorld on 23/02/2021.
//

import UIKit
import CoreData

// MARK: - UITableViewCell 
class Event_Lsit_Cell: UITableViewCell {
    // MARK: - Event_Lsit_Cell Properties
    @IBOutlet weak var viewEventBG: UIView!{
        didSet{
            viewEventBG.layer.cornerRadius = 15
            viewEventBG.backgroundColor = .secondarySystemBackground
        }
    }
    @IBOutlet weak var lblEventTitle: UILabel!
    @IBOutlet weak var lblEventLocation: UILabel!
    @IBOutlet weak var lblEventTime: UILabel!
}
// MARK: - UIViewController
class EventList_VC: UIViewController {
    
    // MARK: - UIViewController Properties
    @IBOutlet weak var eventListColView: UITableView!
    @IBOutlet weak var btnBarMenu: UIBarButtonItem!{
        didSet{
            btnBarMenu.tintColor = .label
        }
    }
    // MARK: - Variables declearations
    let transiton = SlideInTransition()
    var topView: UIView?
    var eventListObject: [NSManagedObject] = []
    
    
    // MARK: - Init
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if Reachability.shared.isConnectedToNetwork(){
            getObjectWith(jsonFileName: "events_list")
        }
        eventListObject = Database_Helper.sharedInstance.onFetch(entityName: "EventList")
    }

    // MARK: - IBAction
    @IBAction func btnMenuAction(_ sender: UIBarButtonItem) {
        
        guard let menuViewController = storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as? MenuViewController else { return }
        menuViewController.didTapMenuType = { menuType in
            self.transitionToNew(menuType)
        }
        menuViewController.modalPresentationStyle = .overCurrentContext
        menuViewController.transitioningDelegate = self
        present(menuViewController, animated: true)
    }
    // Left Menu TransitionToNew Function.
    func transitionToNew(_ menuType: MenuType) {
        let title = String(describing: menuType).capitalized
        self.title = title
        topView?.removeFromSuperview()
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension EventList_VC: UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.height/5
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if eventListObject.count != 0{
            return eventListObject.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Event_Lsit_Cell", for: indexPath) as! Event_Lsit_Cell
        let details = eventListObject[indexPath.row] as NSManagedObject
        cell.lblEventTitle.text = details.value(forKey: "event_title") as? String
        cell.lblEventLocation.text = details.value(forKey: "event_location") as? String
        cell.lblEventTime.text = details.value(forKey: "event_time") as? String
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let viewController = storyboard?.instantiateViewController(withIdentifier: "EventDetail_VC") as! EventDetail_VC
        let details = eventListObject[indexPath.row] as NSManagedObject
        viewController.selectedEventId = details.value(forKey: "event_id") as! Int
        self.navigationController?.pushViewController(viewController, animated: true)
    }
}

// MARK: - UIViewControllerTransitioningDelegate
extension EventList_VC: UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = true
        return transiton
    }

    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = false
        return transiton
    }
}


