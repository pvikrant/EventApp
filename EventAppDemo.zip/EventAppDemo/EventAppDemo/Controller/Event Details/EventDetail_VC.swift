//
//  EventDetail.swift
//  EventAppDemo
//
//  Created by AppEdify TechnoWorld on 28/02/2021.
//

import Foundation
import UIKit
import CoreData

// MARK: - UITableViewCell
class EventImage_Cell: UITableViewCell {
    // MARK: - EventImage_Cell Properties
    @IBOutlet weak var imgEvent: UIImageView!
}
class EventTitle_Cell: UITableViewCell {
    // MARK: - EventTitle_Cell Properties
    @IBOutlet weak var lblEventTitle: UILabel!
    @IBOutlet weak var lblEventTime: UILabel!
}
class EventOrganizerDetails_Cell: UITableViewCell {
    // MARK: - EventOrganizerDetails_Cell Properties
    @IBOutlet weak var lblOrganizerTitle: UILabel!
    @IBOutlet weak var lblOrganizerName: UILabel!
    @IBOutlet weak var lblOrganizerEmail: UILabel!
    @IBOutlet weak var lblOrganizerContact: UILabel!
    @IBOutlet weak var lblOrganizerWebsite: UILabel!
}
class EventDescription_Cell: UITableViewCell {
    // MARK: - EventDescription_Cell Properties
    @IBOutlet weak var lblDescriptionTitle: UILabel!
    @IBOutlet weak var lblDescriptionInfo: UILabel!
}
class EventAttendees_Cell: UITableViewCell {
    // MARK: - EventAttendees_Cell Properties
    @IBOutlet weak var lblSubTitle: UILabel!
    @IBOutlet weak var collectionViewItems: UICollectionView!{
        didSet{
            collectionViewItems.layer.cornerRadius = 10
        }
    }
}
class EventCompanyDetails_Cell: UITableViewCell {
    // MARK: - EventCompanyDetails_Cell Properties
    @IBOutlet weak var lblSubTitle: UILabel!
    @IBOutlet weak var lblCompanyName: UILabel!
    @IBOutlet weak var lblCompanyPhrase: UILabel!
    @IBOutlet weak var lblCompanyBase: UILabel!
}

// MARK: - UICollectionViewCell
class CardView_Items_Cell: UICollectionViewCell {
    // MARK: - CardView_Items_Cell Properties
    @IBOutlet weak var imgPrpfile: UIImageView!{
        didSet{
            imgPrpfile.layer.cornerRadius = imgPrpfile.frame.height/2
        }
    }
    @IBOutlet weak var lblName: UILabel!
}
// MARK: - UIViewController
class EventDetail_VC: UIViewController {
    // MARK: - UIViewController Properties
    @IBOutlet var tblEventDetails: UITableView!
    
    // MARK: - Variables Declearations
    var eventDetailsObject: [NSManagedObject] = []
    var selectedEventId = 0
    let borderColor = UIColor(red:222/255, green:227/255, blue:224/255, alpha: 0.1).cgColor
    let borderWidth = 1
    
    // MARK: - Init
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Check internet availability here.
        if Reachability.shared.isConnectedToNetwork(){
            getObjectWith(jsonFileName: "events_details")
        }
        // Fetch and fillter data from core data object using ID.
        eventDetailsObject = Database_Helper.sharedInstance.onFetchWithPredicate(entityName: "EventDetails", fillterFormet: "d_event_id == %d", byId: selectedEventId) 
    }
}
// MARK: - UITableViewDelegate, UITableViewDataSource
extension EventDetail_VC: UITableViewDelegate, UITableViewDataSource
{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        if eventDetailsObject.count != 0{
            return 8 
        }
        return 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let details = eventDetailsObject[0] as NSManagedObject
        
        if indexPath.row == 0
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "EventImage_Cell") as! EventImage_Cell
            cell.imgEvent.downloaded(from: (details.value(forKey: "d_event_image") as? String)!)
            return cell
        }else if indexPath.row == 1
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "EventTitle_Cell") as! EventTitle_Cell
            cell.layer.borderWidth = CGFloat(borderWidth)
            cell.layer.borderColor = borderColor
            cell.backgroundColor = .secondarySystemBackground
            cell.lblEventTitle.text = details.value(forKey: "d_event_title") as? String
            cell.lblEventTime.text = details.value(forKey: "d_event_time") as? String
            return cell
        }
        else if indexPath.row == 2
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "EventOrganizerDetails_Cell") as! EventOrganizerDetails_Cell
            cell.layer.borderWidth = CGFloat(borderWidth)
            cell.layer.borderColor = borderColor
            cell.backgroundColor = .secondarySystemBackground
            cell.lblOrganizerName.text = details.value(forKey: "d_event_name")! as? String
            cell.lblOrganizerEmail.text = "Email: \(details.value(forKey: "d_event_email")!)"
            cell.lblOrganizerContact.text = "Contact: \(details.value(forKey: "d_event_phone")!)"
            cell.lblOrganizerWebsite.text = "Website: \(details.value(forKey: "d_event_website")!)"
            return cell
        }
        else if indexPath.row == 3
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "EventDescription_Cell") as! EventDescription_Cell
            cell.layer.borderWidth = CGFloat(borderWidth)
            cell.layer.borderColor = borderColor
            cell.backgroundColor = .secondarySystemBackground
            cell.lblDescriptionTitle.text = "About".uppercased()
            cell.lblDescriptionInfo.text = details.value(forKey: "d_event_description") as? String
            return cell
        }
        else if indexPath.row == 4
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "EventAttendees_Cell") as! EventAttendees_Cell
            cell.layer.borderWidth = CGFloat(borderWidth)
            cell.layer.borderColor = borderColor
            cell.backgroundColor = .secondarySystemBackground
            cell.lblSubTitle.text = "Attendees".uppercased()
            return cell
        }
        else if indexPath.row == 5
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "EventDescription_Cell") as! EventDescription_Cell
            cell.layer.borderWidth = CGFloat(borderWidth)
            cell.layer.borderColor = borderColor
            cell.backgroundColor = .secondarySystemBackground
            cell.lblDescriptionTitle.text = "Free Wifi Availabel!".uppercased()
            cell.lblDescriptionTitle.startBlink()
            cell.lblDescriptionTitle.textColor = .label
            cell.lblDescriptionInfo.text = "Wifi Host Name: \(details.value(forKey: "d_event_wifi_name")!) , Password: \(details.value(forKey: "d_event_wifi_password")!)"
            return cell
        }
        else if indexPath.row == 6
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "EventCompanyDetails_Cell") as! EventCompanyDetails_Cell
            cell.layer.borderWidth = CGFloat(borderWidth)
            cell.layer.borderColor = borderColor
            cell.backgroundColor = .secondarySystemBackground
            cell.lblSubTitle.text = "Associated With US".uppercased()
            cell.lblCompanyName.text = details.value(forKey: "d_event_comp_name")! as? String
            cell.lblCompanyPhrase.text = details.value(forKey: "d_event_catchphrase")! as? String
            cell.lblCompanyBase.text = details.value(forKey: "d_event_bs")! as? String
            return cell
        }
        else if indexPath.row == 7
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "EventAttendees_Cell") as! EventAttendees_Cell
            cell.layer.borderWidth = CGFloat(borderWidth)
            cell.layer.borderColor = borderColor
            cell.backgroundColor = .secondarySystemBackground
            cell.lblSubTitle.text = "Sponsors".uppercased()
            return cell
        }
        else{
            return UITableViewCell()
        }
    }
}
// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension EventDetail_VC: UICollectionViewDelegate, UICollectionViewDataSource
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CardView_Items_Cell", for: indexPath) as! CardView_Items_Cell
        
        cell.layer.borderWidth = CGFloat(borderWidth)
        cell.layer.borderColor = borderColor
        cell.layer.cornerRadius = 6
        cell.backgroundColor = .secondarySystemBackground
        cell.lblName.text = "Vikrant"
        return cell
    }
}
// MARK: - UILabel Blinking Extension
extension UILabel {

    func startBlink() {
        UIView.animate(withDuration: 0.8,
              delay:0.0,
              options:[.allowUserInteraction, .curveEaseInOut, .autoreverse, .repeat],
              animations: { self.alpha = 0 },
              completion: nil)
    }
}

// MARK: - Lazy loading images from URL.
extension UIImageView {
    func downloaded(from url: URL, contentMode mode: UIView.ContentMode = .scaleAspectFit) {
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() { [weak self] in
                self?.image = image
            }
        }.resume()
    }
    func downloaded(from link: String, contentMode mode: UIView.ContentMode = .scaleToFill) {
        guard let url = URL(string: link) else { return }
        downloaded(from: url, contentMode: mode)
    }
}
