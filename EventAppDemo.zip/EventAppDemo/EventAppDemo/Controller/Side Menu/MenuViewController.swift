//
//  MenuViewController.swift
//  EventAppDemo
//
//  Created by AppEdify TechnoWorld on 23/02/2021.
//

import UIKit


// MARK: - UITableViewCell
class Menu_Tittle_Cell: UITableViewCell
{
    // MARK: - Menu_Tittle_Cell Properties
    @IBOutlet weak var imgIcon: UIImageView!{
        didSet{ imgIcon.layer.cornerRadius = imgIcon.frame.height / 2.0 }
    }
    @IBOutlet weak var lblTitle: UILabel!{
        didSet{ lblTitle.textColor = .label }
    }
}
class Menu_Items_Cell: UITableViewCell
{
    // MARK: - Menu_Items_Cell Properties
    @IBOutlet weak var btnIcon: UIButton!
    @IBOutlet weak var lblTitle: UILabel!{
        didSet{
            lblTitle.textColor = .label
        }
    }
}
// MARK: - Enumeration Definition for left menu.
enum MenuType: Int {
    case profile
    case events
    case attendees
    case sponsors
    case speakers
    case eventfeeds
    case contactus
    case feedback
}
// MARK: - UIViewController
class MenuViewController: UIViewController {
    
    // MARK: - Variables Declearations
    let arrOfItemsName = ["Vikrant Prajapati","Events","Attendees", "Sponsors", "Speakers","Event Feeds","Contact Us","Feedback"]
    var didTapMenuType: ((MenuType) -> Void)?
}
// MARK: - UITableViewDelegate, UITableViewDataSource
extension MenuViewController: UITableViewDelegate,UITableViewDataSource
{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrOfItemsName.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == 0
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Menu_Tittle_Cell") as! Menu_Tittle_Cell
            cell.lblTitle.text = arrOfItemsName[indexPath.row]
            return cell
        }
        else
        {
            let origImage = UIImage(named: arrOfItemsName[indexPath.row])
            let tintedImage = origImage?.withRenderingMode(.alwaysTemplate)
           
            let cell = tableView.dequeueReusableCell(withIdentifier: "Menu_Items_Cell") as! Menu_Items_Cell
            cell.lblTitle.text = arrOfItemsName[indexPath.row]
            cell.btnIcon.setImage(tintedImage, for: .normal)
            cell.btnIcon.tintColor = .label
            return cell
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard MenuType(rawValue: indexPath.row) != nil else { return }
        dismiss(animated: true, completion: nil)
    }
}
